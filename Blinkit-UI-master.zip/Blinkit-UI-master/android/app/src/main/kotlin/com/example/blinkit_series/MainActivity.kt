package com.example.blinkit_series

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
